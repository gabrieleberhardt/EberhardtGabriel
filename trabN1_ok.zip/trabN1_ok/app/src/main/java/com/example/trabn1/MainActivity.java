package com.example.trabn1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button btnAdicionar;
    private ListView lvCadastro;
   private List<Cadastra> listCadastro;
    private ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvCadastro = findViewById(R.id.lvCadastro);
        btnAdicionar = findViewById(R.id.btdAdd);
        lvCadastro.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                deletar(i);
                return true;
            }
        });

        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, FormularioActivity.class);
                i.putExtra("acao", "inserir");
                startActivity( i );
            }
        });

    }

    protected void onStart(){
        super.onStart();
        carregarCadastro();
    }

    private void carregarCadastro(){
        listCadastro = CadastraDAO.getCadastros(this);

        if(listCadastro.isEmpty()){
            lvCadastro.setEnabled(false);;
            String[] listaVazia = {"Lista Vazia"};
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaVazia);
        }else {
            lvCadastro.setEnabled(true);
            adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listCadastro);

        }
        lvCadastro.setAdapter( adapter );
    }

    private void deletar(int posicao){
        Cadastra cadastra = listCadastro.get(posicao);
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setTitle("Excluir");
        alerta.setIcon(android.R.drawable.ic_dialog_alert);
        alerta.setMessage("Confirma a exclusão de " + cadastra.getNome()+"? ");
        alerta.setNeutralButton("Não", null);
        alerta.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                CadastraDAO.excluir(MainActivity.this,cadastra.getId());;
                carregarCadastro();
            }
        });
        alerta.show();

    }
}