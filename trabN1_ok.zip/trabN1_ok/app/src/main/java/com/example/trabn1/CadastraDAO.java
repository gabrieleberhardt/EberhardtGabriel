package com.example.trabn1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.net.ContentHandler;
import java.util.ArrayList;
import java.util.List;

public class CadastraDAO {

    public static void inserir (Context context, Cadastra cadastra){
        Conexao conn = new Conexao(context);
        SQLiteDatabase db = conn.getWritableDatabase();
        ContentValues valores = new ContentValues();

        valores.put("nome", cadastra.getNome());
        valores.put("fone",cadastra.getFone());

        db.insert("pessoa", null,valores);
    }

    public static void editar(Context context, Cadastra cadastra){
        Conexao conn = new Conexao(context);
        SQLiteDatabase db = conn.getWritableDatabase();
        ContentValues valores = new ContentValues();

        valores.put("nome", cadastra.getNome());
        valores.put("fone", cadastra.getFone());

        db.update("pessoa", valores, " id=" + cadastra.getId(), null);
    }

    public static void excluir(Context context, int idCadastra){
        SQLiteDatabase db = new Conexao(context).getWritableDatabase();

        db.delete("pessoa", " id= " + idCadastra, null );
    }

    public static List<Cadastra> getCadastros(Context context){
        Conexao conn = new Conexao(context);
        SQLiteDatabase db = conn.getReadableDatabase();
        List<Cadastra> lista = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT id, nome, fone FROM pessoa ORDER BY 1", null);

        if (cursor != null && cursor.getCount() >0){
            cursor.moveToFirst();
            do {
                Cadastra cadastra = new Cadastra();
                cadastra.setId(cursor.getInt( 0));
                cadastra.setNome(cursor.getString(1));
                cadastra.setFone(cursor.getString(2));
                lista.add( cadastra );
            }while (cursor.moveToNext());
        }
        return lista;
    }


    public static void getCadastroById(Context context, int idCadastro) {
        SQLiteDatabase db = new Conexao(context).getReadableDatabase();
        Cadastra cadastra = null;
        Cursor cursor = db.rawQuery("SELECT id, nome, fone FROM pessoa " + "WHERE id = " + idCadastro, null );

        if (cursor != null && cursor.getCount()>0){
            cursor.moveToFirst();
            cadastra = new Cadastra();
            cadastra.setId( cursor.getInt(0));
            cadastra.setNome(cursor.getString(1));
            cadastra.setFone(cursor.getString(2));
        }
        //return Cadastra;
    }

}
