package com.example.trabn1;

public class Cadastra {

    private int id;
    private String nome, fone;

    public Cadastra (){

    }

    public Cadastra (int id, String nome, String fone){
        this.id = id;
        this.nome = nome;
        this.fone = fone;
    }

    public String toString() {return nome + " -FONE: " + fone; }

    public int getId() {        return id;    }

    public void setId(int id) {        this.id = id;    }

    public String getNome() {        return nome;    }

    public void setNome(String nome) {        this.nome = nome;    }

    public String getFone() {        return fone;    }

    public void setFone(String fone) {        this.fone = fone;    }
}
