package com.example.trabn1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class FormularioActivity extends AppCompatActivity {

    private EditText etNome, etFone;

    private Button btnSalvar;

    private Cadastra cadastra;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fomulario);

        etNome = findViewById(R.id.etNome);
        etFone = findViewById(R.id.etFone);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { salvar();            }
        });

    }
    private void salvar(){

        String nome = etNome.getText().toString();
        if (nome.isEmpty()){
            Toast.makeText(this, "Escreva seu nome", Toast.LENGTH_LONG).show();
        }else {
            cadastra = new Cadastra();
            cadastra.setNome((etNome.getText().toString()));
            cadastra.setFone((etFone.getText().toString()));
            CadastraDAO.inserir(this,cadastra);
            etNome.setText("");
            etFone.setText("");
            cadastra = null;

            }
        }
    }
